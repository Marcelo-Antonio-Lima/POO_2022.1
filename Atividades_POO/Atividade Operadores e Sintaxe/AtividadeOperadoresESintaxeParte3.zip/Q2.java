/*
class Main {
  public static void main(String[] args) {
    int tabela=5;
    for(int i = 0;i<tabela+1;i++){
      for(int j = 1;j<i+1;j++){
        System.out.print(i*j+" ");
        }
      System.out.println("");
      }
    }    
  }
*/