/*
class Main {
  public static void main(String[] args) {
    int fatorial;
    for(int i = 1;i<11;i++){
      System.out.print(i+"! = ");
      fatorial = 1;
      for(int j = i;j>0;j--){
        fatorial*=j;
        }
      System.out.println(fatorial);
      }
    }    
  }
*/