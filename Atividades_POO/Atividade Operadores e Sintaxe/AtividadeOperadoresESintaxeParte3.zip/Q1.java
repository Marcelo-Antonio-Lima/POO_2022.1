/*
class Main {
  public static void main(String[] args) {
    int varx=13;
    while(varx != 1){
      if(varx % 2 == 0){
        varx = varx/2;
        if (varx == 1){
          System.out.print(varx);
        }
        else{
          System.out.print(varx+" -->");
        }
      }  
      else{          
        varx = 3 * varx + 1;
        System.out.print(varx+" -->");
      }
    }    
  }
}
*/